package org.example;

import java.util.Scanner;
/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {
        /*Scanner sc = new Scanner(System.in);
        System.out.println("Nhap so can check: ");
        int CheckNumber = sc.nextInt();
        boolean check = CheckSNT(CheckNumber);
        if (check == true) {
            System.out.println(CheckNumber + " la so nguyen to");
        } else if (check == false) {
            System.out.println(CheckNumber + " khong phai la so nguyen to");
        }*/
        int[] Array = {1, 2, 4, 5, 8, 9};
        for (int i = 0; i < Array.length; i++) {
            if (CheckSNT(Array[i]) == true) {
                System.out.println(Array[i]);
            }
        }
        /* tinh tong cac phan tu trong mang*/

        int[] Array2 = {8,7,6,5};
        System.out.println(SumArray(Array2));
        DaoNguocMang(Array2);


    }

    /*Method check so nguyen to*/
        public static boolean CheckSNT(int Number){
            double i = 2;
            boolean kq = true;
            if (Number <= 2) {
                kq = false;
            } else {
                while (i <= Math.sqrt(Number)) {
                    if (Number % i == 0) {
                        kq = false;
                        i = Math.sqrt(Number) + 1;
                    }
                    else i = i + 1;
                }
            }
            return kq;
        }
        /* Method kiểm tra 1 số có vừa chia hết cho 2 và vừa chia hết cho 3 hay không */
        public static boolean Chiahetcho2va3(int n) {
            boolean kq = true;
            if (n % 2 == 0 && n % 3 ==0) {
                kq = true;
            }
            else kq = false;
            return kq;
        }
        /*Method tính tổng các phần tử trong mảng */
        public static int SumArray (int[] Array){
            int Sum = 0;
            for (int i = 0; i < Array.length; i++) {
                Sum = Sum + Array[i];
            }
            return Sum;
        }
        /*Method đảo ngược mảng*/
        public static void DaoNguocMang(int[] Array1) {
            for (int i = Array1.length - 1; i >= 0; i--) {
                System.out.println(Array1[i]);

            }
        }
    }

